﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CursoDesktop
{
    public class Produto
    {
        public int Codigo { get; set; }
        public String Descricao { get; set; }
        public double Valor { get; set; }
        public String Fabricante { get; set; }
    }
}
